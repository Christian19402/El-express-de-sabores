// URL base de la API
const API_URL = 'http://localhost:3000';

// Estado de la aplicación
let currentTab = 'tacos';
let menuData = { tacos: [], bebidas: [] };

// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  initializeApp();
});

async function initializeApp() {
  setupNavigation();
  setupTabs();
  await loadMenu();
  await loadContactInfo();
}

// ============================================
// NAVEGACIÓN
// ============================================
function setupNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Remover clase active de todos los links
      navLinks.forEach(l => l.classList.remove('active'));
      
      // Agregar clase active al link clickeado
      link.classList.add('active');
      
      // Scroll suave a la sección
      const targetId = link.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        targetSection.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

function scrollToMenu() {
  const menuSection = document.querySelector('#menu');
  menuSection.scrollIntoView({ behavior: 'smooth' });
}

// ============================================
// TABS DEL MENÚ
// ============================================
function setupTabs() {
  const tabs = document.querySelectorAll('.tab');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remover clase active de todos los tabs
      tabs.forEach(t => t.classList.remove('active'));
      
      // Agregar clase active al tab clickeado
      tab.classList.add('active');
      
      // Cambiar el contenido mostrado
      currentTab = tab.getAttribute('data-tab');
      renderMenu();
    });
  });
}

// ============================================
// CARGA DE DATOS DESDE LA API
// ============================================
async function loadMenu() {
  try {
    const response = await fetch(`${API_URL}/menu`);
    
    if (!response.ok) {
      throw new Error('Error al cargar el menú');
    }
    
    const data = await response.json();
    menuData = data.data;
    renderMenu();
    
  } catch (error) {
    console.error('Error:', error);
    showError('menu-grid', 'No se pudo cargar el menú. Asegúrate de que el servidor esté corriendo en http://localhost:3000');
  }
}

async function loadContactInfo() {
  try {
    const response = await fetch(`${API_URL}/contacto`);
    
    if (!response.ok) {
      throw new Error('Error al cargar la información de contacto');
    }
    
    const data = await response.json();
    renderContactInfo(data.data);
    
  } catch (error) {
    console.error('Error:', error);
    showError('contact-info', 'No se pudo cargar la información de contacto.');
  }
}

// ============================================
// RENDERIZADO DEL MENÚ
// ============================================
function renderMenu() {
  const menuGrid = document.getElementById('menu-grid');
  const items = menuData[currentTab];
  
  if (!items || items.length === 0) {
    menuGrid.innerHTML = '<p class="loading">No hay productos disponibles</p>';
    return;
  }
  
  menuGrid.innerHTML = items.map(item => `
    <div class="menu-item" onclick="showDetail(${item.id}, '${currentTab}')">
      <div class="item-icon">${item.imagen}</div>
      <h3 class="item-nombre">${item.nombre}</h3>
      <p class="item-descripcion">${item.descripcion}</p>
      <p class="item-precio">$${item.precio} MXN</p>
    </div>
  `).join('');
}

// ============================================
// MODAL DE DETALLE
// ============================================
async function showDetail(id, type) {
  const modal = document.getElementById('product-detail');
  
  // Si es un taco, hacer petición específica al endpoint
  if (type === 'tacos') {
    try {
      const response = await fetch(`${API_URL}/menu/tacos/${id}`);
      
      if (!response.ok) {
        throw new Error('Producto no encontrado');
      }
      
      const data = await response.json();
      const item = data.data;
      
      // Rellenar el modal con los datos
      document.getElementById('detail-icon').textContent = item.imagen;
      document.getElementById('detail-nombre').textContent = item.nombre;
      document.getElementById('detail-descripcion').textContent = item.descripcion;
      document.getElementById('detail-precio').textContent = item.precio;
      
      // Mostrar el modal
      modal.classList.remove('hidden');
      
    } catch (error) {
      console.error('Error:', error);
      alert('No se pudo cargar el detalle del producto');
    }
  } else {
    // Para bebidas, usar los datos ya cargados
    const item = menuData.bebidas.find(b => b.id === id);
    
    if (item) {
      document.getElementById('detail-icon').textContent = item.imagen;
      document.getElementById('detail-nombre').textContent = item.nombre;
      document.getElementById('detail-descripcion').textContent = item.descripcion;
      document.getElementById('detail-precio').textContent = item.precio;
      
      modal.classList.remove('hidden');
    }
  }
}

function closeDetail() {
  const modal = document.getElementById('product-detail');
  modal.classList.add('hidden');
}

// Cerrar modal al hacer clic fuera del contenido
document.addEventListener('click', (e) => {
  const modal = document.getElementById('product-detail');
  if (e.target === modal) {
    closeDetail();
  }
});

// ============================================
// RENDERIZADO DE INFORMACIÓN DE CONTACTO
// ============================================
function renderContactInfo(contacto) {
  const contactGrid = document.getElementById('contact-info');
  
  contactGrid.innerHTML = `
    <div class="contact-card">
      <div class="contact-icon">📞</div>
      <h3>Teléfono</h3>
      <p>${contacto.telefono}</p>
    </div>
    
    <div class="contact-card">
      <div class="contact-icon">📧</div>
      <h3>Email</h3>
      <p>${contacto.email}</p>
    </div>
    
    <div class="contact-card">
      <div class="contact-icon">🕒</div>
      <h3>Horario</h3>
      <p>${contacto.horario}</p>
    </div>
    
    <div class="contact-card">
      <div class="contact-icon">📍</div>
      <h3>Ubicación</h3>
      <p>${contacto.direccion}</p>
    </div>
    
    <div class="contact-card">
      <div class="contact-icon">📱</div>
      <h3>Redes Sociales</h3>
      <p>Facebook: ${contacto.redes.facebook}</p>
      <p>Instagram: ${contacto.redes.instagram}</p>
    </div>
  `;
}

// ============================================
// MANEJO DE ERRORES
// ============================================
function showError(containerId, message) {
  const container = document.getElementById(containerId);
  container.innerHTML = `
    <div class="loading" style="color: #FF6B35;">
      ⚠️ ${message}
    </div>
  `;
}

// ============================================
// OBSERVADOR DE SCROLL PARA NAVEGACIÓN
// ============================================
const sections = document.querySelectorAll('section[id]');

window.addEventListener('scroll', () => {
  let current = '';
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;
    
    if (scrollY >= sectionTop - 200) {
      current = section.getAttribute('id');
    }
  });
  
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${current}`) {
      link.classList.add('active');
    }
  });
});

// ============================================
// MENSAJES DE CONSOLA
// ============================================
console.log('%c🌮 El Express de Sabores', 'font-size: 20px; font-weight: bold; color: #FFB800;');
console.log('%cFrontend conectado a la API en ' + API_URL, 'color: #666;');
console.log('%c¡Disfruta navegando por nuestro menú!', 'color: #FF6B35;');
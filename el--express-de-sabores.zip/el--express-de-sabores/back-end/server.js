const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middlewares
app.use(cors()); // Permitir peticiones desde el frontend
app.use(express.json());

// Base de datos 
const menu = {
  tacos: [
    { 
      id: 1, 
      nombre: "Taco al pastor", 
      precio: 25,
      descripcion: "Carne de cerdo marinada con especias y piña",
      imagen: "🌮"
    },
    { 
      id: 2, 
      nombre: "Taco de asada", 
      precio: 30,
      descripcion: "Carne de res asada con cebolla y cilantro",
      imagen: "🌮"
    },
    { 
      id: 3, 
      nombre: "Taco de suadero", 
      precio: 28,
      descripcion: "Carne suave y jugosa con limón",
      imagen: "🌮"
    },
    { 
      id: 4, 
      nombre: "Taco vegetariano", 
      precio: 22,
      descripcion: "Verduras asadas con queso y aguacate",
      imagen: "🥙"
    }
  ],
  bebidas: [
    { 
      id: 1, 
      nombre: "Agua de horchata", 
      precio: 15,
      descripcion: "Bebida tradicional de arroz y canela",
      imagen: "🍹"
    },
    { 
      id: 2, 
      nombre: "Refresco", 
      precio: 20,
      descripcion: "Coca-Cola, Sprite o Fanta",
      imagen: "🥤"
    },
    { 
      id: 3, 
      nombre: "Agua de Jamaica", 
      precio: 15,
      descripcion: "Refrescante bebida de flor de jamaica",
      imagen: "🍸"
    }
  ]
};

const contacto = {
  nombre: "El Express de Sabores",
  telefono: "555-123-4567",
  email: "contacto@expressabores.com",
  horario: "Lunes a Domingo, 12:00 - 22:00",
  direccion: "Av. Reforma #123, Ciudad de México",
  redes: {
    facebook: "@expressabores",
    instagram: "@expressabores"
  }
};

// RUTAS DE LA API

// Ruta principal - Mensaje de bienvenida
app.get('/', (req, res) => {
  res.json({
    mensaje: "¡Bienvenido a El Express de Sabores! 🌮",
    descripcion: "API REST para nuestro food truck",
    version: "1.0.0",
    endpoints: {
      menu_completo: "/menu",
      tacos: "/menu/tacos",
      taco_por_id: "/menu/tacos/:id",
      contacto: "/contacto"
    }
  });
});

// Obtener menú completo (tacos + bebidas)
app.get('/menu', (req, res) => {
  res.json({
    success: true,
    data: menu
  });
});

// Obtener solo tacos
app.get('/menu/tacos', (req, res) => {
  res.json({
    success: true,
    data: menu.tacos
  });
});

// Obtener taco por ID
app.get('/menu/tacos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const taco = menu.tacos.find(t => t.id === id);
  
  if (taco) {
    res.json({
      success: true,
      data: taco
    });
  } else {
    res.status(404).json({
      success: false,
      error: "Taco no encontrado",
      mensaje: `No existe un taco con el ID ${id}`
    });
  }
});

// Obtener solo bebidas
app.get('/menu/bebidas', (req, res) => {
  res.json({
    success: true,
    data: menu.bebidas
  });
});

// Obtener información de contacto
app.get('/contacto', (req, res) => {
  res.json({
    success: true,
    data: contacto
  });
});

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: "Ruta no encontrada",
    mensaje: `La ruta ${req.url} no existe en nuestra API`
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
  console.log(`📋 Endpoints disponibles:`);
  console.log(`   GET /`);
  console.log(`   GET /menu`);
  console.log(`   GET /menu/tacos`);
  console.log(`   GET /menu/tacos/:id`);
  console.log(`   GET /menu/bebidas`);
  console.log(`   GET /contacto`);
});